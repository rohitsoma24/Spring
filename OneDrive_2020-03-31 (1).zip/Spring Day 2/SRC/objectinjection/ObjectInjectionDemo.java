package com.mphasis.springday2.objectinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ObjectInjectionDemo {

	public static void main(String[] args) {
		
		 ApplicationContext context = new ClassPathXmlApplicationContext("/com/mphasis/springday2/objectinjection/config.xml");	
		 
		 Employee employee1 = context.getBean("employee1",Employee.class);
		 System.out.println(employee1);
		 
		 Employee employee2 = context.getBean("employee2",Employee.class);
		 System.out.println(employee2);
	}

}
