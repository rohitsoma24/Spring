package com.mphasis.mapinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/mphasis/mapinjection/config.xml");
		
		Customer c = context.getBean("customer",Customer.class);
		
		System.out.println(c);
	}

}
