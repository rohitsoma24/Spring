package com.mphasis.springday2.propertyinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PropertiesInjectionsDemo {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/mphasis/springday2/propertyinjection/config.xml");
		
		MyDAO dao = context.getBean("mydao",MyDAO.class);
		
		System.out.println(dao);
	}

}
