package com.mphasis.springday2.annotationapproach;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnotationApproachDemo {

	public static void main(String[] args) {
		
		 ApplicationContext context = new ClassPathXmlApplicationContext("/com/mphasis/springday2/annotationapproach/config.xml");	
		 
		 Employee employee1 = context.getBean("employee1",Employee.class);
		 System.out.println(employee1);
		 
		 Employee employee2 = context.getBean("employee2",Employee.class);
		 System.out.println(employee2);
		 
		 Employee employee3 = context.getBean("employeeBean",Employee.class);
		 employee3.setId(1000);
		 employee3.setName("Kiran");
		 System.out.println(employee3);
		 
		 
		 Employee employee4 = context.getBean("employeeBean",Employee.class);
		 employee4.setId(2222);
		 employee4.setName("Seeta");
		 System.out.println(employee4);
		 
		 System.out.println(employee1.hashCode());
		 System.out.println(employee2.hashCode());
		 System.out.println(employee3.hashCode());
		 System.out.println(employee4.hashCode());
		 
	}

}
