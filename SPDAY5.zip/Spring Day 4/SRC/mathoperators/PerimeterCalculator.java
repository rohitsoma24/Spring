package com.mphasis.springday4.mathoperators;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("pc")
public class PerimeterCalculator {

	@Value("#{ 2 * (rectangle.length + rectangle.breadth) }")
	private double rectanglePerimeter;

	public double getRectanglePerimeter() {
		return rectanglePerimeter;
	}
}
