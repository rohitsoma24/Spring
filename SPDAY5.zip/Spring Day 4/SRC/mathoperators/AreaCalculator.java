package com.mphasis.springday4.mathoperators;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("ac")
public class AreaCalculator {
	  // PI * radius * radius
	 
	 @Value("#{ T(java.lang.Math).PI * circle.radius * circle.radius }")
	 private double areaOfCircle;

	public double getAreaOfCircle() {
		
		return areaOfCircle;
	}

	public void setAreaOfCircle(double areaOfCircle) {
		this.areaOfCircle = areaOfCircle;
	}
	 
	 
}
