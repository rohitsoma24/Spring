package com.mphasis.springday4.mathoperators;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.mphasis.springday4.mathoperators")
public class AppConfig {

	 @Bean("rectangle")
	 public Rectangle getRectangle() {
		 
		  return new Rectangle(12, 23);
	 }
	 
	 @Bean("circle")
	 public Circle getCircle() {
		 return new Circle(12);
	 }
}
