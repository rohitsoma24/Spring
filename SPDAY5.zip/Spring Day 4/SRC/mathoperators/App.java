package com.mphasis.springday4.mathoperators;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		
		 ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		 
		 PerimeterCalculator pc = context.getBean("pc",PerimeterCalculator.class);
		 
		 System.out.println("Perimeter of Rectangle = "+pc.getRectanglePerimeter());
		 
		 System.out.println("============================================================");
		 
		 AreaCalculator ac = context.getBean("ac",AreaCalculator.class);
		 System.out.println("Area of Circle = "+ac.getAreaOfCircle());
	}

}
