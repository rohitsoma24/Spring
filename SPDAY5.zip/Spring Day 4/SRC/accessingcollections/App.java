package com.mphasis.springday4.accessingcollections;

import java.util.Collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		StudentListAccessor accessor = context.getBean("accessor",StudentListAccessor.class);
		
		System.out.println("Third Student from a List :");
		System.out.println(accessor.getThirdStudentInList());
		
		System.out.println("====================================================");
		
		System.out.println("List of Failed Students :");
		accessor.getFailedStudents().forEach(System.out::println); 
		
		Collections.sort(accessor.getStudents(), (o1,o2) -> o1.getMarks() - o2.getMarks());
		
		System.out.println("====================================================");
		System.out.println("Student Names sorted according to the Marks :");
		accessor.getStudents().stream().map(i -> i.getName()).forEach(System.out::println);
		
		System.out.println("====================================================");
		System.out.println("Student Names :");
		accessor.getStudentNames().forEach(System.out::println);
		
		System.out.println("====================================================");
		System.out.println("First Name from a Map");
		StudentMapAccessor mapAccessor = context.getBean("studentMapAccessor",StudentMapAccessor.class);
		System.out.println(mapAccessor.getFirstStudentName());
		
		
		
	}
}
