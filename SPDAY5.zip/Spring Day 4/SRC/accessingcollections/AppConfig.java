package com.mphasis.springday4.accessingcollections;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.mphasis.springday4.accessingcollections")
public class AppConfig {

	 @Bean("studentList")
	 public List<Student> getStudentList(){
		 
		  List<Student> students = new ArrayList<Student>();
		  students.add(new Student("John", 50));
		  students.add(new Student("Rocky", 80));
		  students.add(new Student("Jimmy", 20));
		  students.add(new Student("Cassy", 30));
		  
		  return students;
	 }
	 
	 @Bean
	 public Map<Integer, Student> getStudentMap(){
		
		  Map<Integer, Student> map = new LinkedHashMap<Integer, Student>();
		  map.put(101, new Student("Rocky", 70));
		  map.put(102, new Student("John", 80));
		  
		  return map;
	 }
	 
	 
}
