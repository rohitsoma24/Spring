package com.mphasis.springday4.accessingcollections;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class StudentMapAccessor {

	@Value("#{getStudentMap[101].name}")
	private String firstStudentName;

	public String getFirstStudentName() {
		return firstStudentName;
	}

	public void setFirstStudentName(String firstStudentName) {
		this.firstStudentName = firstStudentName;
	}
	
	
}
