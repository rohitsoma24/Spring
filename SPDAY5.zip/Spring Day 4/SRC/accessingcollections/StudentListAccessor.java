package com.mphasis.springday4.accessingcollections;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("accessor")
public class StudentListAccessor {

	 @Value("#{ studentList[2] }")
	 private Student thirdStudentInList;
	 
	 @Value("#{studentList.?[marks lt 40]}")
	 private List<Student> failedStudents;
	 
	 @Value("#{studentList.![name]}")
	 private List<String> studentNames;
	 
	 @Value("#{studentList}")
	 private List<Student> students;
	 
	 
	public Student getThirdStudentInList() {
		return thirdStudentInList;
	}
	public void setThirdStudentInList(Student thirdStudentInList) {
		this.thirdStudentInList = thirdStudentInList;
	}
	public List<Student> getFailedStudents() {
		return failedStudents;
	}
	public void setFailedStudents(List<Student> failedStudents) {
		this.failedStudents = failedStudents;
	}
	public List<String> getStudentNames() {
		return studentNames;
	}
	public void setStudentNames(List<String> studentNames) {
		this.studentNames = studentNames;
	}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	 
	 
}
