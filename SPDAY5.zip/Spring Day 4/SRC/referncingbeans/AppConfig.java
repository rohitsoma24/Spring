package com.mphasis.springday4.referncingbeans;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.mphasis.springday4.referncingbeans")
public class AppConfig {

	  @Bean("bookCollection")
	  public BookCollection getBookCollection() {
		  
		  BookCollection collection = new BookCollection();  
		  List<Book> bookList = new ArrayList<Book>();
		  
		  bookList.add(new Book(1, "Spring In Action"));
		  bookList.add(new Book(2, "Spring Recipies"));
		  bookList.add(new Book(3, "Spring MVC"));
		  
		  collection.setBookList(bookList);
		  
		  return collection;
	  }
}
