package com.mphasis.springday4.referncingbeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		BookLibrary bookLibrary = context.getBean("library",BookLibrary.class);
		
		System.out.println("All Books in the Library :");
		bookLibrary.getAllBooks().forEach(System.out::println);
		
		System.out.println("==================================================");
		System.out.println("First Book In the Library :");
		System.out.println(bookLibrary.getGetFirstBook());
		
		
	}

}
