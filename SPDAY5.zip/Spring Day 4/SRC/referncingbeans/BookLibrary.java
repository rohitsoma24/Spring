package com.mphasis.springday4.referncingbeans;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("library")
public class BookLibrary {

	 @Value("#{bookCollection.bookList}")
	 private List<Book> allBooks;
	 
	 @Value("#{bookCollection.getFirstBook()}")
	 private Book getFirstBook;

	public List<Book> getAllBooks() {
		return allBooks;
	}
	
	public Book getGetFirstBook() {
		return getFirstBook;
	}

	
	 
}
