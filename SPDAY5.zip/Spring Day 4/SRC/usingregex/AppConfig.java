package com.mphasis.springday4.usingregex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.mphasis.springday4.usingregex")
public class AppConfig {

	  @Bean("user")
	  public User getUser() {
		  
		  User user = new User();
		  user.setEmail("anupk@gmail.com");
		  user.setPassword("Anup@1234");
		  return user;
	  }
}
