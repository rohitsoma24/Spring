package com.mphasis.springday4.usingregex;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		UserValidator validator = context.getBean("validator",UserValidator.class);
		
		System.out.println("Email Valid = "+validator.isEmailValid());
		System.out.println("Password Valid = "+validator.isPasswordValid());
		System.out.println("Message = "+validator.getValidationMessage());
		
		
	}

}
