package com.mphasis.springday4.usingregex;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("validator")
public class UserValidator {

	@Value("#{user.email matches '^(.+)@(.+)$' }")
	private boolean isEmailValid;
	
	@Value("#{user.password matches '((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})'}")
	private boolean isPasswordValid;
	
	@Value("#{validator.isEmailValid() and validator.isPasswordValid()"
			+ "? 'Valid Email and Password..' : 'Invalid Email or Password!!!'}")
	private String validationMessage;

	public boolean isEmailValid() {
		return isEmailValid;
	}

	public void setEmailValid(boolean isEmailValid) {
		this.isEmailValid = isEmailValid;
	}

	public boolean isPasswordValid() {
		return isPasswordValid;
	}

	public void setPasswordValid(boolean isPasswordValid) {
		this.isPasswordValid = isPasswordValid;
	}

	public String getValidationMessage() {
		return validationMessage;
	}

	public void setValidationMessage(String validationMessage) {
		this.validationMessage = validationMessage;
	}
	
	
	
}
