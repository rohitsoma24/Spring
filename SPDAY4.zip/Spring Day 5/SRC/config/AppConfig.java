package com.mphasis.springday5.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.mphasis.springday5.models.Circle;
import com.mphasis.springday5.models.Rectangle;

@Configuration
@ComponentScan("com.mphasis.springday5")
@EnableAspectJAutoProxy
public class AppConfig {

	 @Bean("circle")
	 public Circle getCircle() {
		 Circle c = new Circle();
		c.setName("Circle 1");
		 return c;
	 }
	 
	 @Bean("rectangle")
	 public Rectangle getRectangle() {
		 Rectangle r = new Rectangle();
		 r.setName("Rectangle 1");
		 return r;
	 }
}
