package com.mphasis.springday5.models;

public class Rectangle {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
