package com.mphasis.springday5.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.springday5.models.Circle;
import com.mphasis.springday5.models.Rectangle;

@Service("service")
public class ShapeService {

	 @Autowired
	 private Circle circle;
	 
	 @Autowired
	 private Rectangle rectangle;
	 
	public Circle getCircle() {
		return circle;
	}
	public void setCircle(Circle circle) {
		this.circle = circle;
	}
	public Rectangle getRectangle() {
		return rectangle;
	}
	public void setRectangle(Rectangle rectangle) {
		this.rectangle = rectangle;
	}
	 
	 
}
