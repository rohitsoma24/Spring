package com.mphasis.springday5.aspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	
	//  "execution(public String getName())" is called as Point cut Expression
	
//	 @Before(value ="allGetters() && allCircleGetters()")
//	 public void loggingAdvice() {
//		System.out.println("Advice Before Execution of getName "); 
//	 }
	 
//	 @Before(value ="allGetters()")
//	 public void secondAdvice() {
//		 System.out.println("Second Advice Before Execution of getName ");
//	 }
//	
	
	
//	@Before("args(circleName)")
//	public void thirdAdvice(String circleName) {
//		
//		// Validation code..
//		System.out.println("Before Setter Method Called... "+circleName);
//	}

//	@After("args(name)")
//	public void fourthAdvice(String name) {
//		System.out.println("After Setter Method Called..."+name);
//	}
	
//	@AfterReturning("args(name)")
//	public void fifthAdvice(String name) {
//		System.out.println("AfterReturning advice method Called..."+name);
//	}
	
//	@AfterThrowing("args(name)")
//	public void fifthAdvice(String name) {
//		System.out.println("AfterThrowing advice method Called..."+name);
//	}
	
	@Around("args(name)")
	public Object myAroundAdvice(ProceedingJoinPoint proceedingJoinPoint,String name) {

		Object object = null;

		try {

			// Before 
			
			System.out.println("Before advice "+name);
			
			object = proceedingJoinPoint.proceed(); // getName circle class
			
			System.out.println("After advice");
			// After Returning

		} catch (Throwable e) {

			System.out.println("After Throwing");
			
		}
		
		// After finally
		System.out.println("Finally Advice");
		
		return object;
	}
	
	
	 @Pointcut("execution(public * get*())")  // getName, getAnything - String
	 public void allGetters() {}
	 
	 @Pointcut("within(com.mphasis.springday5.models.Circle)")
	 public void allCircleMethods() {}
	 
	 
	 
	 
	 
	 
	 
}
