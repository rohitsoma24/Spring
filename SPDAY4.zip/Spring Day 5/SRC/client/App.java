package com.mphasis.springday5.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mphasis.springday5.config.AppConfig;
import com.mphasis.springday5.services.ShapeService;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		ShapeService service = context.getBean("service",ShapeService.class);
		
		service.getCircle().setName("Dummy Circle");
		
		//System.out.println(service.getCircle().getName());
		
		//System.out.println(service.getRectangle().getName());
	}

}
