package com.mphasis.springday3_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        
        Student student1 = context.getBean("student1", Student.class);
        Student student2 = context.getBean("student", Student.class);
        Student student3 = context.getBean("student", Student.class);
        
        System.out.println(student1); // 101 Anup
        
        student2.setId(102);
        student2.setName("Geeta");
        System.out.println(student2); // 0 null
        
        System.out.println(student3); // 0 null
        
        System.out.println(student1.hashCode()); // hashcode1
        System.out.println(student2.hashCode()); // hashcode2 
        System.out.println(student3.hashCode()); // hashcode2
        
    }
}
