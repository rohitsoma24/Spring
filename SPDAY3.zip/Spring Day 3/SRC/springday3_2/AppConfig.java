package com.mphasis.springday3_2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan(basePackages = {"com.mphasis.springday3_2"})
public class AppConfig {

		@Bean("student1")   // Object will be part of IOC container
	    //@Scope("prototype")
		public Student getStudent() {
			return new Student(101, "Anup");
		}
}
