package com.mphasis.springday3_2.example2;

public interface Instrument {
	
	void play();
}
