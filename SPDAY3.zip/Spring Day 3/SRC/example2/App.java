package com.mphasis.springday3_2.example2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		Musician musician = context.getBean("musician2",Musician.class);
		//musician.setSong("Tum hi ho");
		musician.performance();
		
	}
}
