package com.mphasis.springday3_2.example2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.mphasis.springday3_2.example2"})
public class AppConfig {

	 @Bean("musician2")
	 public Musician getMusician() {
		 
		 return new Musician("Tum mile Dil Khile..");
	 }
}
