package com.mphasis.springday3_2.example2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Musician {

	private String song;
	
	@Autowired
	@Qualifier("piano")
	private Instrument instrument;
	
	public Musician() {
		
	}

	public Musician(String song) {
		
		this.song = song;
	}
	
	
	
	public String getSong() {
		return song;
	}

	public void setSong(String song) {
		this.song = song;
	}

	public void performance() {
		
		System.out.println("Performing song.. "+song+" by");
		instrument.play();
	}
	
	
}
