package com.mphasis.springday3_1;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Hello implements InitializingBean,DisposableBean {

	
	public void afterPropertiesSet() throws Exception {
		System.out.println("afterPropertiesSet method in Hello class");
		
	}
	
	public void destroy() throws Exception {
		System.out.println("destroy method in Hello class");
		
	}

	

//	public void init() {
//		System.out.println("init method in Hello class");
//	}
//	
//	public void destroy() {
//		System.out.println("destroy method in Hello class");
//	}
}
