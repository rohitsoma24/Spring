package com.mphasis.springday3_1;

import java.sql.*;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;

public class ProductDAO {

	@Value("${driver}")
	@NonNull
	private String driver;
	
	@Value("${url}")
	private String url;
	
	@Value("${user}")
	private String username;
	
	@Value("${password}")
	private String password;
	
	
	Connection con;
	
	//@PostConstruct
	public void init() throws ClassNotFoundException, SQLException {
		System.out.println("ProductDAO init method");
		createConnection();
	}
	
	
	public void createConnection() throws ClassNotFoundException, SQLException {
		
		 Class.forName(driver);		 
		 con = DriverManager.getConnection(url, username, password);
		 System.out.println("Connection is Created..");
	}
	
	public void getAllProducts() throws ClassNotFoundException, SQLException {
		
		 
		 Statement statement = con.createStatement();	 
		 ResultSet rst = statement.executeQuery("select * from product");
		 while(rst.next()) {
			 System.out.println(rst.getInt(1)+ "  "+ rst.getString(2)+"  "+rst.getDouble(3));
		 }
	}
	
	public void deleteProductById(int id) throws SQLException, ClassNotFoundException {
		
		 PreparedStatement pst = con.prepareStatement("delete from product where id=?");
		 pst.setInt(1, id);
		 int i = pst.executeUpdate();
		 System.out.println("Product with id = "+id+" is deleted rows affected = "+i);
		 
	}
	
	//@PreDestroy
	public void destroy() throws SQLException {
		System.out.println("destroy method from ProdcutDAO");
		closeConnection();
	}
	
	public void closeConnection() throws SQLException {
		con.close();
		System.out.println("Connection is closed..");
	}
	
	
}
