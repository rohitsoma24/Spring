package com.mphasis.springday3_1;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args ) throws ClassNotFoundException, SQLException{
    
    	ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
    	
    	ProductDAO dao = context.getBean("productDao",ProductDAO.class);
    	
    	dao.deleteProductById(4);
    	dao.getAllProducts();
    	
    	((ClassPathXmlApplicationContext)context).close();
    	
//    	((ClassPathXmlApplicationContext)context).refresh();
//    	ProductDAO dao2 = context.getBean("productDao",ProductDAO.class);
//    	((ClassPathXmlApplicationContext)context).close();
    }
}
